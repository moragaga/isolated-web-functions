# Este espejo conserva la estructura y el comportamiento del código productivo.
from __future__ import annotations


# Agrupa un contrato con una responsabilidad y estado claramente delimitados.
class DemoIds:
    INTERVAL = 'operational-trace-demo-interval'

    @staticmethod
    # Ejecuta esta responsabilidad aislada sin ampliar el alcance del módulo.
    def status(scope_id: str) -> str:
        return f'{scope_id}-demo-status'
