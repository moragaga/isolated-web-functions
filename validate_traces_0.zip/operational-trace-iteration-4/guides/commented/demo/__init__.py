# Este espejo conserva la estructura y el comportamiento del código productivo.
from __future__ import annotations


# Ejecuta esta responsabilidad aislada sin ampliar el alcance del módulo.
def build_demo_layout(*args, **kwargs):
    from .build import build_demo_layout as builder

    return builder(*args, **kwargs)


# Ejecuta esta responsabilidad aislada sin ampliar el alcance del módulo.
def register_demo_callbacks(*args, **kwargs):
    from .callbacks import register_demo_callbacks as register

    return register(*args, **kwargs)


__all__ = ('build_demo_layout', 'register_demo_callbacks')
