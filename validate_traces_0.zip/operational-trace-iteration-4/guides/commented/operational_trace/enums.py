# Este espejo conserva la estructura y el comportamiento del código productivo.
from __future__ import annotations

from enum import Enum


# Agrupa un contrato con una responsabilidad y estado claramente delimitados.
class OperationalTraceMode(str, Enum):
    PROCESS = 'process'
    DISTRIBUTED = 'distributed'
    INTEGRATED_OPERATIONS = 'integrated-operations'


# Agrupa un contrato con una responsabilidad y estado claramente delimitados.
class AlarmTone(str, Enum):
    CRITICAL = 'critical'
    WARNING = 'warning'
    NEUTRAL = 'neutral'
