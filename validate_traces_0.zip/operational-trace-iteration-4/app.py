from __future__ import annotations

import dash_bootstrap_components as dbc
from dash import Dash

from demo import build_demo_layout, register_demo_callbacks
from operational_trace import register_operational_trace_callbacks


app = Dash(
    __name__,
    external_stylesheets=[dbc.icons.BOOTSTRAP],
    suppress_callback_exceptions=True,
)
app.layout = build_demo_layout()

for scope_id in (
    'process-demo',
    'distributed-demo',
    'integrated-demo',
):
    register_operational_trace_callbacks(
        app=app,
        scope_id=scope_id,
    )

register_demo_callbacks(app=app)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8050)
