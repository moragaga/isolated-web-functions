from __future__ import annotations

import importlib
import sys
import types
import unittest

from demo.data import build_integrated_definition


class FakeComponent:
    def __init__(self, *args, **kwargs):
        self.args = args
        self.children = kwargs.pop('children', None)
        self.properties = kwargs
        for key, value in kwargs.items():
            setattr(self, key, value)


class ComponentFactory:
    def __getattr__(self, name):
        return type(name, (FakeComponent,), {})


class BuildWithStubTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        dash_module = types.ModuleType('dash')
        dash_module.dcc = ComponentFactory()
        dash_module.html = ComponentFactory()
        development_module = types.ModuleType('dash.development')
        base_component_module = types.ModuleType('dash.development.base_component')
        base_component_module.Component = FakeComponent
        sys.modules.setdefault('dash', dash_module)
        sys.modules.setdefault('dash.development', development_module)
        sys.modules.setdefault('dash.development.base_component', base_component_module)

    def test_integrated_module_contains_static_baseline_and_dynamic_routes(self) -> None:
        build = importlib.import_module('operational_trace.build')
        definition = build_integrated_definition(revision=0)
        module = build.build_operational_trace_module(definition=definition)
        trace = module.children[3]
        classes = [child.properties.get('className') for child in trace.children]

        self.assertIn('operational-trace__baseline', classes)
        self.assertEqual(len(trace.children[0].children), 6)
        self.assertEqual(len(trace.children[2].children), 9)

    def test_local_integrated_alarm_builds_no_horizontal_trunk(self) -> None:
        build = importlib.import_module('operational_trace.build')
        definition = build_integrated_definition(revision=0)
        routes = build.build_alarm_routes(definition=definition)
        local_route = next(
            route
            for route in routes
            if route.properties['data-alarm-id'] == 'io-mp10'
        )
        child_classes = [child.properties['className'] for child in local_route.children]

        self.assertEqual(
            child_classes,
            ['operational-trace__route-local-connector'],
        )


if __name__ == '__main__':
    unittest.main()
