from __future__ import annotations

import pathlib
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]


class SourceContractTests(unittest.TestCase):
    def test_operational_baseline_is_full_width_and_static(self) -> None:
        css = (ROOT / 'assets/operational_trace/00_operational_trace.css').read_text()

        self.assertIn('.operational-trace__baseline', css)
        self.assertIn('inset-inline: 0;', css)
        self.assertNotIn('operational-trace__route-guide', css)

    def test_dynamic_routes_do_not_define_a_global_upper_line(self) -> None:
        build = (ROOT / 'operational_trace/build.py').read_text()

        self.assertNotIn("className='operational-trace__route-guide'", build)
        self.assertIn("className='operational-trace__route-trunk'", build)

    def test_markers_use_bootstrap_chevrons_inside_process_points(self) -> None:
        build = (ROOT / 'operational_trace/build.py').read_text()

        self.assertIn("html.I(className='bi bi-chevron-up')", build)
        self.assertIn("html.I(className='bi bi-chevron-down')", build)
        self.assertIn('*_build_point_markers', build)

    def test_productive_python_has_no_comment_lines(self) -> None:
        for path in (ROOT / 'operational_trace').glob('*.py'):
            lines = path.read_text().splitlines()
            self.assertFalse(
                any(line.lstrip().startswith('#') for line in lines),
                path.name,
            )


if __name__ == '__main__':
    unittest.main()
