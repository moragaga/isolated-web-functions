from __future__ import annotations

import unittest

from operational_trace.state import SelectionState, reconcile_selection


class SelectionTests(unittest.TestCase):
    def test_polling_does_not_select_an_alarm(self) -> None:
        state = reconcile_selection(
            click_timestamps=(-1, -1),
            selector_keys=('a#1', 'b#1'),
            available_selection_keys=('a#1', 'b#1'),
            current_state=SelectionState(),
        )

        self.assertIsNone(state.selection_key)

    def test_selection_survives_data_refresh_for_same_occurrence(self) -> None:
        state = reconcile_selection(
            click_timestamps=(-1, -1),
            selector_keys=('a#1', 'b#1'),
            available_selection_keys=('a#1', 'b#1'),
            current_state=SelectionState(
                selection_key='b#1',
                last_event_timestamp=100,
            ),
        )

        self.assertEqual(state.selection_key, 'b#1')

    def test_second_click_deselects_same_occurrence(self) -> None:
        state = reconcile_selection(
            click_timestamps=(150,),
            selector_keys=('a#1',),
            available_selection_keys=('a#1',),
            current_state=SelectionState(
                selection_key='a#1',
                last_event_timestamp=100,
            ),
        )

        self.assertIsNone(state.selection_key)

    def test_new_occurrence_in_same_slot_clears_selection(self) -> None:
        state = reconcile_selection(
            click_timestamps=(-1,),
            selector_keys=('a#2',),
            available_selection_keys=('a#2',),
            current_state=SelectionState(
                selection_key='a#1',
                last_event_timestamp=100,
            ),
        )

        self.assertIsNone(state.selection_key)
        self.assertEqual(state.last_event_timestamp, 100)

    def test_distributed_rotation_does_not_change_selected_occurrence(self) -> None:
        state = reconcile_selection(
            click_timestamps=(-1, -1, -1),
            selector_keys=('south#1', 'central#1', 'north#1'),
            available_selection_keys=('south#1', 'central#1', 'north#1'),
            current_state=SelectionState(
                selection_key='central#1',
                last_event_timestamp=200,
            ),
        )

        self.assertEqual(state.selection_key, 'central#1')


if __name__ == '__main__':
    unittest.main()
