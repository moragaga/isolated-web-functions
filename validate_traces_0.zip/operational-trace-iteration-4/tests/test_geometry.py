from __future__ import annotations

import unittest

from demo.data import build_integrated_definition, build_process_definition
from operational_trace.geometry import resolve_alarm_route_geometry
from operational_trace.placement import resolve_alarm_placements


class GeometryTests(unittest.TestCase):
    def test_integrated_local_alarm_is_only_vertical(self) -> None:
        definition = build_integrated_definition(revision=0)
        alarm = next(alarm for alarm in definition.alarms if alarm.alarm_id == 'io-mp10')
        placement = resolve_alarm_placements(definition=definition)[alarm.selection_key]
        geometry = resolve_alarm_route_geometry(
            definition=definition,
            alarm=alarm,
            placement=placement,
        )

        self.assertFalse(geometry.has_horizontal_trunk)
        self.assertTrue(geometry.is_local_route)
        self.assertAlmostEqual(geometry.card_x_percent, geometry.origin_x_percent)

    def test_integrated_route_is_bounded_by_its_real_scope(self) -> None:
        definition = build_integrated_definition(revision=0)
        alarm = next(alarm for alarm in definition.alarms if alarm.alarm_id == 'io-loading')
        placement = resolve_alarm_placements(definition=definition)[alarm.selection_key]
        geometry = resolve_alarm_route_geometry(
            definition=definition,
            alarm=alarm,
            placement=placement,
        )

        self.assertGreater(geometry.trunk_start_x_percent, 0)
        self.assertLess(geometry.trunk_end_x_percent, 100)
        self.assertAlmostEqual(geometry.trunk_start_x_percent, 100 / 6, places=5)
        self.assertAlmostEqual(geometry.trunk_end_x_percent, 350 / 9, places=5)

    def test_process_route_reaches_center_without_using_full_width(self) -> None:
        definition = build_process_definition(revision=0)
        alarm = definition.ordered_alarms[0]
        placement = resolve_alarm_placements(definition=definition)[alarm.selection_key]
        geometry = resolve_alarm_route_geometry(
            definition=definition,
            alarm=alarm,
            placement=placement,
        )

        self.assertTrue(geometry.has_horizontal_trunk)
        self.assertGreater(geometry.trunk_start_x_percent, 0)
        self.assertEqual(geometry.trunk_end_x_percent, 50)
        self.assertLess(geometry.trunk_end_x_percent, 100)

    def test_operational_process_point_stays_centered(self) -> None:
        definition = build_process_definition(revision=0)
        alarm = definition.ordered_alarms[2]
        placement = resolve_alarm_placements(definition=definition)[alarm.selection_key]
        geometry = resolve_alarm_route_geometry(
            definition=definition,
            alarm=alarm,
            placement=placement,
        )

        self.assertEqual(geometry.origin_x_percent, 50)


if __name__ == '__main__':
    unittest.main()
