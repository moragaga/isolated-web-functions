from __future__ import annotations

import unittest

from demo.data import (
    build_distributed_definition,
    build_integrated_definition,
    build_process_definition,
)
from operational_trace.placement import resolve_alarm_placements


class PlacementTests(unittest.TestCase):
    def test_process_alarms_keep_left_to_right_order(self) -> None:
        definition = build_process_definition(revision=0)
        placements = resolve_alarm_placements(definition=definition)

        self.assertEqual(
            [placements[alarm.selection_key].slot_index for alarm in definition.ordered_alarms],
            [0, 1, 2, 3],
        )

    def test_distributed_alarms_share_last_slot_when_isolated(self) -> None:
        definition = build_distributed_definition(revision=0)
        placements = resolve_alarm_placements(definition=definition)
        distributed_slots = {
            placements[alarm.selection_key].slot_index
            for alarm in definition.alarms
            if alarm.is_distributed
        }

        self.assertEqual(distributed_slots, {5})

    def test_integrated_cards_follow_real_process_columns(self) -> None:
        definition = build_integrated_definition(revision=0)
        placements = resolve_alarm_placements(definition=definition)
        by_rule = {
            alarm.alarm_id: placements[alarm.selection_key].slot_index
            for alarm in definition.alarms
        }

        self.assertEqual(by_rule['io-mp10'], 0)
        self.assertEqual(by_rule['io-loading'], 1)
        self.assertEqual(by_rule['io-crushing'], 3)
        self.assertEqual(by_rule['io-grinding'], 5)
        self.assertEqual(by_rule['io-recovery'], 6)
        self.assertEqual(by_rule['io-port'], 8)

    def test_integrated_cards_leave_one_mine_and_two_plant_columns_empty(self) -> None:
        definition = build_integrated_definition(revision=0)
        placements = resolve_alarm_placements(definition=definition)
        mine_slots = {
            placements[alarm.selection_key].slot_index
            for alarm in definition.alarms
            if alarm.placement_group_key == 'mine'
        }
        plant_slots = {
            placements[alarm.selection_key].slot_index
            for alarm in definition.alarms
            if alarm.placement_group_key == 'plant'
        }

        self.assertEqual(len(set(range(4)) - mine_slots), 1)
        self.assertEqual(len(set(range(4, 9)) - plant_slots), 2)


if __name__ == '__main__':
    unittest.main()
