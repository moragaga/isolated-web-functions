const assert = require('assert');
const {
    resolveSelection,
    resolveRenderState,
} = require('../assets/operational_trace/operational_trace.js');

const selectorsV1 = [
    {alarm: 'a#1'},
    {alarm: 'b#1'},
];

const initial = resolveSelection(
    [-1, -1],
    {selection_keys: ['a#1', 'b#1'], version: '0'},
    selectorsV1,
    {selection_key: null, last_event_timestamp: -1}
);
assert.strictEqual(initial.selection_key, null);

const selected = resolveSelection(
    [100, -1],
    {selection_keys: ['a#1', 'b#1'], version: '0'},
    selectorsV1,
    initial
);
assert.strictEqual(selected.selection_key, 'a#1');

const refreshed = resolveSelection(
    [-1, -1],
    {selection_keys: ['a#1', 'b#1'], version: '1'},
    selectorsV1,
    selected
);
assert.strictEqual(refreshed.selection_key, 'a#1');

const replaced = resolveSelection(
    [-1, -1],
    {selection_keys: ['a#2', 'b#1'], version: '2'},
    [{alarm: 'a#2'}, {alarm: 'b#1'}],
    refreshed
);
assert.strictEqual(replaced.selection_key, null);

const selectedAgain = resolveSelection(
    [200, -1],
    {selection_keys: ['a#2', 'b#1'], version: '2'},
    [{alarm: 'a#2'}, {alarm: 'b#1'}],
    replaced
);
assert.strictEqual(selectedAgain.selection_key, 'a#2');

const deselected = resolveSelection(
    [250, -1],
    {selection_keys: ['a#2', 'b#1'], version: '2'},
    [{alarm: 'a#2'}, {alarm: 'b#1'}],
    selectedAgain
);
assert.strictEqual(deselected.selection_key, null);

const renderState = resolveRenderState(
    {selection_key: 'b#1', last_event_timestamp: 300},
    {selection_keys: ['a#2', 'b#1']},
    [{alarm: 'a#2'}, {alarm: 'b#1'}],
    [{alarm: 'a#2'}, {alarm: 'b#1'}],
    [{alarm: 'a#2'}, {alarm: 'b#1'}, {alarm: 'b#1'}]
);
assert.deepStrictEqual(renderState, [
    'b#1',
    'true',
    ['false', 'true'],
    ['false', 'true'],
    ['false', 'true'],
    ['false', 'true', 'true'],
]);

console.log('operational-trace-iteration-4-clientside-ok');
