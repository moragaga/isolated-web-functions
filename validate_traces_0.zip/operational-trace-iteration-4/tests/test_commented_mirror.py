from __future__ import annotations

import ast
import pathlib
import re
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]


class CommentedMirrorTests(unittest.TestCase):
    def test_python_mirror_has_equivalent_ast(self) -> None:
        sources = [
            ROOT / 'app.py',
            *sorted((ROOT / 'operational_trace').glob('*.py')),
            *sorted((ROOT / 'demo').glob('*.py')),
        ]
        for source in sources:
            mirror = ROOT / 'guides/commented' / source.relative_to(ROOT)
            self.assertTrue(mirror.exists(), source.name)
            self.assertEqual(
                ast.dump(ast.parse(source.read_text()), include_attributes=False),
                ast.dump(ast.parse(mirror.read_text()), include_attributes=False),
                source.name,
            )

    def test_css_mirror_keeps_the_same_rules(self) -> None:
        for filename in ('00_operational_trace.css', '01_demo.css'):
            source = ROOT / 'assets/operational_trace' / filename
            mirror = ROOT / 'guides/commented/assets/operational_trace' / filename
            self.assertEqual(
                self._strip_css_comments(source.read_text()),
                self._strip_css_comments(mirror.read_text()),
            )

    def test_javascript_mirror_keeps_the_same_program(self) -> None:
        source = ROOT / 'assets/operational_trace/operational_trace.js'
        mirror = ROOT / 'guides/commented/assets/operational_trace/operational_trace.js'
        self.assertEqual(
            self._strip_javascript_comments(source.read_text()),
            self._strip_javascript_comments(mirror.read_text()),
        )

    def _strip_css_comments(self, value: str) -> str:
        without_comments = re.sub(r'/\*.*?\*/', '', value, flags=re.DOTALL)
        return re.sub(r'\s+', ' ', without_comments).strip()

    def _strip_javascript_comments(self, value: str) -> str:
        return '\n'.join(
            line
            for line in value.splitlines()
            if not line.lstrip().startswith('//')
        ).strip()


if __name__ == '__main__':
    unittest.main()
