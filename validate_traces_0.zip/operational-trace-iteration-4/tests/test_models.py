from __future__ import annotations

import unittest

from operational_trace.enums import AlarmTone, OperationalTraceMode
from operational_trace.models import (
    AlarmDefinition,
    OperationalTraceDefinition,
    OperationalTraceGroup,
    OperationalTracePoint,
)


class ModelTests(unittest.TestCase):
    def test_occurrence_id_defaults_to_alarm_id(self) -> None:
        alarm = AlarmDefinition.from_iterable(
            alarm_id='alarm-a',
            occurrence_id=None,
            title='Alarm A',
            criticality='C1',
            active_time='1 h',
            tone=AlarmTone.CRITICAL,
            origin_process_key='process',
            display_order=0,
        )

        self.assertEqual(alarm.selection_key, 'alarm-a')

    def test_integrated_group_accepts_three_visible_alarms(self) -> None:
        definition = self._integrated_definition(alarm_count=3)

        self.assertEqual(len(definition.alarms), 3)

    def test_integrated_group_rejects_four_visible_alarms(self) -> None:
        with self.assertRaisesRegex(ValueError, 'capacity was exceeded'):
            self._integrated_definition(alarm_count=4)

    def test_integrated_alarm_must_start_inside_placement_group(self) -> None:
        points = tuple(
            OperationalTracePoint(key=f'p{index}', label=f'P{index}')
            for index in range(4)
        )
        alarm = self._alarm(
            alarm_id='a',
            occurrence_id='a#1',
            origin='p3',
            group='left',
        )

        with self.assertRaisesRegex(ValueError, 'origin must belong'):
            OperationalTraceDefinition.from_iterables(
                scope_id='scope',
                mode=OperationalTraceMode.INTEGRATED_OPERATIONS,
                points=points,
                alarms=(alarm,),
                groups=(
                    OperationalTraceGroup.from_iterable(
                        key='left',
                        label='Left',
                        point_keys=('p0', 'p1'),
                        max_visible_alarm_count=2,
                    ),
                    OperationalTraceGroup.from_iterable(
                        key='right',
                        label='Right',
                        point_keys=('p2', 'p3'),
                        max_visible_alarm_count=2,
                    ),
                ),
            )

    def test_same_rule_can_have_a_new_occurrence(self) -> None:
        first = self._alarm(
            alarm_id='same-rule',
            occurrence_id='same-rule#1',
            origin='process',
        )
        second = self._alarm(
            alarm_id='same-rule',
            occurrence_id='same-rule#2',
            origin='process',
        )

        self.assertNotEqual(first.selection_key, second.selection_key)

    def _integrated_definition(self, *, alarm_count: int) -> OperationalTraceDefinition:
        points = tuple(
            OperationalTracePoint(key=f'p{index}', label=f'P{index}')
            for index in range(4)
        )
        alarms = tuple(
            self._alarm(
                alarm_id=f'a{index}',
                occurrence_id=f'a{index}#1',
                origin=f'p{index}',
                group='all',
                order=index,
            )
            for index in range(alarm_count)
        )
        return OperationalTraceDefinition.from_iterables(
            scope_id='scope',
            mode=OperationalTraceMode.INTEGRATED_OPERATIONS,
            points=points,
            alarms=alarms,
            groups=(
                OperationalTraceGroup.from_iterable(
                    key='all',
                    label='All',
                    point_keys=tuple(point.key for point in points),
                    max_visible_alarm_count=3,
                ),
            ),
        )

    def _alarm(
        self,
        *,
        alarm_id: str,
        occurrence_id: str,
        origin: str,
        group: str | None = None,
        order: int = 0,
    ) -> AlarmDefinition:
        return AlarmDefinition.from_iterable(
            alarm_id=alarm_id,
            occurrence_id=occurrence_id,
            title=alarm_id,
            criticality='C1',
            active_time='1 h',
            tone=AlarmTone.CRITICAL,
            origin_process_key=origin,
            display_order=order,
            placement_group_key=group,
        )


if __name__ == '__main__':
    unittest.main()
