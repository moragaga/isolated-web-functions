from __future__ import annotations

import unittest

from demo.data import (
    build_distributed_definition,
    build_integrated_definition,
    build_process_definition,
    resolve_demo_revision,
    resolve_distributed_active_selection_key,
)


class DemoUpdateTests(unittest.TestCase):
    def test_revision_changes_every_three_polls(self) -> None:
        self.assertEqual(resolve_demo_revision(n_intervals=0), 0)
        self.assertEqual(resolve_demo_revision(n_intervals=2), 0)
        self.assertEqual(resolve_demo_revision(n_intervals=3), 1)
        self.assertEqual(resolve_demo_revision(n_intervals=6), 2)
        self.assertEqual(resolve_demo_revision(n_intervals=9), 3)

    def test_regular_updates_keep_occurrence_identity(self) -> None:
        before = build_integrated_definition(revision=0)
        after = build_integrated_definition(revision=2)
        before_keys = {alarm.alarm_id: alarm.selection_key for alarm in before.alarms}
        after_keys = {alarm.alarm_id: alarm.selection_key for alarm in after.alarms}

        self.assertEqual(before_keys, after_keys)

    def test_fourth_revision_replaces_selected_occurrence(self) -> None:
        before = build_process_definition(revision=2)
        after = build_process_definition(revision=3)
        before_torque = next(alarm for alarm in before.alarms if alarm.alarm_id == 'process-torque')
        after_torque = next(alarm for alarm in after.alarms if alarm.alarm_id == 'process-torque')

        self.assertNotEqual(before_torque.selection_key, after_torque.selection_key)

    def test_distributed_rotation_keeps_alarm_tone_bound_to_occurrence(self) -> None:
        definition = build_distributed_definition(revision=0)
        central = next(
            alarm
            for alarm in definition.alarms
            if alarm.alarm_id == 'distributed-central'
        )

        self.assertEqual(central.tone.value, 'critical')
        self.assertIn(
            resolve_distributed_active_selection_key(n_intervals=1, revision=0),
            {alarm.selection_key for alarm in definition.alarms},
        )


if __name__ == '__main__':
    unittest.main()
